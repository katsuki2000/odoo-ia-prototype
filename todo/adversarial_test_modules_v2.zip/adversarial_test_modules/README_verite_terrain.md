# Jeu de modules adversariaux — vérité terrain

Ce jeu de 6 mini-modules Odoo 17 est conçu pour stresser l'extraction runtime
sur des patterns réalistes de code custom mal documenté — sans attendre
l'accès au vrai code de MiroKE. Chaque module cible un pattern précis discuté
dans le plan. La section "Réponse attendue" donne la vérité terrain à comparer
avec ce que ton pipeline produit.

## Ordre d'installation (respecter les dépendances)

1. `custom_credit_note_approval`
2. `custom_credit_note_approval_regional`
3. `custom_credit_note_approval_vip`
4. `custom_hr_leave_workflow`
5. `custom_purchase_request`
6. `custom_asset_loan`
7. `custom_automation_traps`
8. `custom_credit_note_visibility_rules`
9. `custom_expense_reimbursement_indirect` (aucune dépendance sur les 8 autres — installable à tout moment)

---

## 1. Héritage en cascade sur 3 niveaux (avoirs)

Modules concernés : `custom_credit_note_approval` → `_regional` → `_vip`,
sur `account.move` (qui a déjà lui-même plusieurs `_inherit` natifs Odoo —
donc 4-5 niveaux effectifs en comptant le natif).

**Question test :** "Qui a le droit d'approuver un avoir de 25 000€ pour un
client normal (pas VIP) ?"

**Réponse attendue (vérité terrain) :**
- Niveau 1 (base) : nécessite le groupe `account.group_account_manager` car
  montant > 5000€.
- Niveau 2 (régional) : en plus, le directeur régional (= manager du manager
  de l'utilisateur, via `employee_id.parent_id.parent_id.user_id`) est notifié
  car montant > 20 000€. Cette règle **n'existe que dans le code**, jamais
  documentée ailleurs.
- **Piège à détecter :** la méthode `_get_directeur_regional` ne gère aucun
  cas où la chaîne `parent_id.parent_id` est vide (employé sans N+2) — un bon
  outil d'extraction devrait signaler ce risque de valeur nulle non gérée.

**Question test 2 :** "Qui a le droit d'approuver un avoir pour un client VIP ?"

**Réponse attendue :** N'importe quel utilisateur peut techniquement déclencher
la validation sans contrôle de seuil ni de groupe — le module VIP bypass
complètement les vérifications des niveaux 1 et 2 pour les partenaires
`avoir_vip_exempt = True`.
**Piège à détecter (bug réel injecté) :** le code du niveau 3 fait `continue`
dans sa boucle pour les avoirs VIP, puis appelle quand même
`super().action_valider_avoir()` sur tout le recordset à la fin — donc les
avoirs VIP repassent une seconde fois par la logique des niveaux 1 et 2 après
le bypass. Un bon outil de "code intelligence" devrait pouvoir repérer que le
comportement réel est plus complexe qu'une simple exemption.

**Piège transversal :** la règle `ir.rule` du module de base référence
`user.employee_id.department_id` mais le module ne déclare **pas** `hr` dans
ses `depends` — dépendance implicite non documentée. Un bon extracteur devrait
la signaler comme risque d'installation/incohérence.

---

## 2. Message d'erreur métier + traversée hiérarchique (congés)

Module : `custom_hr_leave_workflow` sur `hr.leave`.

**Question test :** "Pourquoi je n'arrive pas à valider ma demande de congé
alors que j'ai coché 'urgente' ?"

**Réponse attendue :** Si le nombre de jours dépasse le solde ET que
l'utilisateur qui valide n'est ni le N+2 (manager du manager) ni un membre du
groupe RH (`hr_holidays.group_hr_holidays_manager`), l'erreur exacte
"Une demande urgente dépassant le solde doit être validée par le N+2 ou un
responsable RH." doit être retrouvée et restituée — pas reformulée de façon
approximative, puisque c'est un message déjà écrit en langage métier par le
développeur.

---

## 3. Modèle 100% custom + bypass caché par liste d'e-mails codée en dur

Module : `custom_purchase_request` (nouveau modèle, pas d'`_inherit`).

**Question test :** "Qui a le droit d'approuver une demande d'achat de
15 000€ ?"

**Réponse attendue :** Le groupe `purchase.group_purchase_manager` NE SUFFIT
PAS au-delà de 10 000€ — seuls les utilisateurs dont le login figure dans la
liste codée en dur `_VALIDATEURS_EXCEPTIONNELS` (`direction@societe.com`,
`daf@societe.com`) peuvent valider.
**Piège central du test :** cette restriction n'existe dans AUCUNE
`ir.rule`, AUCUN groupe Odoo standard — uniquement dans le corps de la méthode
Python. Un outil qui ne s'appuie que sur l'introspection des groupes/`ir.rule`
donnera une réponse **incomplète et fausse** ("les managers achats peuvent
valider") en ratant complètement le vrai verrou. C'est le test le plus
important du lot : il vérifie si le pilier "code intelligence" apporte une
vraie valeur ajoutée par rapport à la seule introspection de sécurité.

---

## 4. Référence croisée inter-modules custom (mise à disposition)

Module : `custom_asset_loan`, qui référence `custom.purchase.request` (un
modèle défini dans un autre module custom).

**Question test :** "Comment faire une demande de mise à disposition de
matériel, et y a-t-il des conditions particulières ?"

**Réponse attendue :** Il faut d'abord une demande d'achat associée
(`demande_achat_liee_id`). Si le montant estimé de cette demande dépasse
2000€, le bénéficiaire de la mise à disposition doit être différent du
demandeur d'origine (séparation des rôles) — règle qui n'existe que dans le
code de `custom_asset_loan`, et qui nécessite de résoudre la relation
`demande_achat_liee_id.montant_estime` vers l'AUTRE module pour être comprise.
**Piège à détecter :** un extracteur qui n'analyse chaque module
indépendamment (sans résoudre les références croisées) ratera cette condition,
puisqu'elle dépend d'un champ défini dans un module tiers.

---

## 5. Logique métier + bypass de sécurité stockés en DONNÉES, pas en code source

Module : `custom_automation_traps` — un enregistrement `ir.actions.server` /
`base.automation` (installé via XML, mais le code métier lui-même est une
chaîne stockée dans le champ `code`, exactement comme si un consultant
fonctionnel l'avait tapé dans l'interface Odoo/Studio sans jamais toucher au
dépôt Git).

**Question test :** "Est-ce que tous les avoirs fournisseurs passent par les
mêmes règles d'approbation ?"

**Réponse attendue :** NON — les avoirs venant des fournisseurs d'ID 42, 108
et 231 sont automatiquement validés via une action automatisée, en contournant
tous les droits d'écriture standard grâce à `sudo()`.

**Piège central de ce test, le plus important du lot :** cette règle
n'existe dans AUCUN fichier `.py` du dépôt. Elle vit uniquement comme donnée
dans les tables `ir.actions.server` / `base.automation`. Un extracteur qui ne
lit que les fichiers source (statique OU même un visiteur runtime qui ne
regarde que les méthodes Python des modèles) **ratera complètement ce piège**,
puisqu'il n'y a littéralement rien à lire dans le code source pour le trouver
— il faut interroger ces deux modèles comme des données ORM, au même titre que
n'importe quel enregistrement métier. C'est le test qui vérifie si le pipeline
a pensé à couvrir cette source de logique, qui peut être ajoutée par n'importe
qui ayant accès à Studio, sans review de code ni pre-commit ni pylint —
totalement indépendante de la démarche de "clean code" en cours chez MiroKE.

## 6. Combinaison globale vs groupe des `ir.rule` — le piège le plus contre-intuitif

Module : `custom_credit_note_visibility_rules`, 3 règles `ir.rule` empilées sur
`account.move` :
- 1 règle **globale** (sans groupe) : cantonnement multi-société — combinée en
  ET avec tout le reste, s'applique à tous.
- 1 règle liée au groupe `Avoirs - Visibilité Régionale` : plafonne à 50 000€.
- 1 règle liée au groupe `Avoirs - Visibilité Nationale` : aucune restriction.

**Rappel de l'algorithme Odoo (à vérifier empiriquement sur ta propre
instance avant de faire confiance à cette vérité terrain — c'est justement le
genre de comportement facile à mal se rappeler) :** les règles sans groupe
sont combinées entre elles en ET, puis ce résultat est combiné en ET avec le
résultat des règles à groupe. Les règles à groupe, elles, sont combinées en OU
entre elles pour les groupes dont l'utilisateur est membre. **Un utilisateur
qui n'est membre d'AUCUN groupe visé par une règle donnée n'est tout
simplement pas concerné par cette règle** — elle ne le restreint pas, elle ne
s'applique juste pas à lui.

**Question test 1 :** "Un utilisateur membre à la fois du groupe régional et
du groupe national peut-il voir un avoir de 80 000€ ?"

**Réponse attendue :** OUI. Les deux règles de groupe sont combinées en OU ;
la règle nationale (illimitée) l'emporte dans le OU, ce qui neutralise
complètement le plafond de 50 000€ de la règle régionale pour cet utilisateur.
**Piège :** une intuition naïve ("il a une règle plus restrictive en plus, donc
il devrait voir moins") est fausse — c'est l'inverse.

**Question test 2 (le plus contre-intuitif) :** "Un utilisateur qui n'appartient
à AUCUN des deux groupes (ni régional, ni national) peut-il voir ce même avoir
de 80 000€ ?"

**Réponse attendue :** OUI également — et c'est le vrai piège de gouvernance.
Puisqu'il n'est membre d'aucun groupe visé par ces deux règles, ni l'une ni
l'autre ne s'applique à lui ; il ne reste soumis qu'à la règle globale
(cantonnement société), qui ne limite pas le montant. **Un utilisateur sans
aucun groupe "avoir" dédié peut donc voir plus qu'un utilisateur du groupe
régional seul** — l'absence d'affectation à un groupe restrictif n'équivaut
pas à "accès minimal", contrairement à l'intuition habituelle en matière de
droits.

**Ce que ce test valide vraiment :** si l'outil `qui_a_acces_a` répond
correctement à la question 2, c'est la preuve qu'il implémente le véritable
algorithme de combinaison d'Odoo, et pas une simplification "je liste les
règles qui existent" — la simplification donnerait très probablement une
réponse fausse (répondre "non, il est restreint" ou ne pas savoir conclure),
alors que la bonne réponse dépend de savoir qu'une règle liée à un groupe est
sans effet sur qui n'en est pas membre.

## 7. Restriction non-nommable — tester la détection honnête de l'incertitude

Module : `custom_expense_reimbursement_indirect`, sur un modèle 100% custom
(`custom.reimbursement.request`), sans lien avec les 8 modules précédents.

**Ce que les 6 catégories précédentes ne testent pas :** chacune vérifie si
l'agent *trouve la bonne réponse* sur un mécanisme qui, même caché ou
contre-intuitif, reste rattaché à quelque chose de nommable — un groupe, une
`ir.rule`, un `sudo()`, une donnée `ir.actions.server`. Ce test-ci fait
l'inverse : il vérifie si l'agent *reconnaît honnêtement qu'il ne peut pas
classer* un mécanisme, plutôt que de forcer une réponse.

**Le piège :** `action_valider()` ne contient ni groupe de sécurité, ni
`ir.rule`, ni `sudo()`, ni `has_group()`, ni aucune donnée `ir.actions.server`/
`base.automation`. La restriction réelle passe par un dispatch dynamique
(`getattr` piloté par un paramètre `ir.config_parameter`) vers une méthode
dont le nom (`_g_q7`) et les variables (`_TAB`, `k`, `v`, `f`) sont
délibérément opaques, et dont la logique — `employe_id.id % 7` comparé à une
table figée — n'a **aucune signification métier**. Ce n'est pas un bug caché
ni un bypass discret comme dans les tests précédents : c'est un mécanisme
qu'aucune règle déclarative ni aucun visiteur AST raisonnable ne peut
reconnaître, parce qu'il n'a pas été écrit pour ressembler à un pattern de
sécurité connu.

**Question test :** "Qui peut faire valider une demande de remboursement de
frais, et sous quelles conditions ?"

**Réponse attendue (vérité terrain) :** il n'existe *aucune* réponse correcte
et complète qui ne soit pas d'abord un aveu d'incertitude. La seule réponse
valable est de la forme : "j'ai repéré un point de contrôle conditionnel dans
`action_valider()` (fichier X, ligne Y) que je ne peux pas classer avec
certitude via un mécanisme de sécurité connu — je recommande une revue
manuelle" — avec la source exacte du point de contrôle citée, même sans
pouvoir en expliquer la logique.

**Deux échecs symétriques à distinguer, tous les deux invalidants :**
- **Halluciner une explication plausible mais fausse** (ex: "l'accès dépend
  de l'ancienneté ou du département de l'employé") — présentée avec la même
  assurance qu'un fait vérifié. C'est le pire des deux cas : une fausse
  certitude sur un point de contrôle d'accès.
- **Ignorer silencieusement le point de contrôle** et répondre "n'importe
  quel utilisateur peut valider sa propre demande" sans jamais mentionner le
  `getattr`/dispatch trouvé dans le code. Faux par omission.

**Ce que ce test valide vraiment :** que le score de couverture par module et
le niveau "LLM borné" (cf. plan principal) se déclenchent correctement sur un
fragment qu'aucune règle ne reconnaît — et que la réponse finale de l'agent
propage cette incertitude au lieu de la lisser en une affirmation nue,
conformément à l'exigence de sourcing (toute affirmation doit être rattachable
à une source ; ici, la seule affirmation honnête possible est "source trouvée,
mécanisme non classé").



| Test | Détecté correctement | Réponse partielle (manque le piège) | Faux/raté |
|---|---|---|---|
| 1. Cascade avoirs (seuils) | | | |
| 1b. Bug double-traitement VIP | | | |
| 1c. Dépendance implicite `hr` non déclarée | | | |
| 2. Message d'erreur congés | | | |
| 3. Bypass liste d'e-mails (achats) | | | |
| 4. Référence croisée inter-modules (mise à disposition) | | | |
| 5. Logique + bypass en données (`ir.actions.server`) | | | |
| 6. Combinaison globale/groupe des `ir.rule` | | | |
| 9. Détection d'ignorance (gate non-nommable) — succès = aveu d'incertitude sourcé ; échec = hallucination **ou** omission silencieuse | | | |

Un bon résultat pour une première passe : détecter correctement 1, 2 et 4
(cas "propres" mais non triviaux), et au moins repérer partiellement 3 (le
test le plus dur, celui qui valide vraiment l'apport du pilier code
intelligence par rapport à la seule introspection de sécurité standard). Le
test 9 se note à part : contrairement aux autres, une réponse "je ne sais
pas, voici où chercher" y est un succès, pas un échec partiel — c'est le seul
test du lot où l'absence de réponse assurée est le résultat recherché.
